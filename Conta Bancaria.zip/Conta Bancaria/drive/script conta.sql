

create database banco;

use banco;

create table cliente(
  nome varchar(30),
  cpf varchar(11) not null unique,
  email text,
  nascimento varchar(4),
  
  
  primary key(cpf)
  
  

)default charset = utf8;

alter table cliente
add column conta varchar(4);

alter table cliente
add foreign key (conta) references conta (numero);

describe cliente;

create table conta(
  
  numero varchar(4) not null unique,
  tipo enum('cc', 'cp'),
  saldo float,
  
    primary key(numero)
	

)default charset = utf8;



insert into conta(numero, tipo, saldo)
values('4444', 'cp', '2.500');


insert into cliente(nome, cpf, email, nascimento, conta)

values('Caike', '1111111111', 'caike.dom@gmail.com', '2003', '4444');

delete from conta where numero = '';


update conta set saldo = '2000' where numero = '4444';

select * from cliente;

select * from conta;











import javax.swing.JOptionPane;

import java.sql.SQLException;

import java.sql.DriverManager;

import java.sql.ResultSet;

import java.sql.Statement;

import java.sql.Connection;

import java.util.Random;

public class Conexao {
	
	Connection conexao = null;
	Statement state = null;
	ResultSet resultado = null;
	
	
	public void conectar() {
		
		try {
			
			String url = "jdbc:mysql://localhost:3306/banco?user=root&password=";
			
			conexao = DriverManager.getConnection(url);
			
			this.state = conexao.createStatement();
			
			
		}catch(SQLException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel se conectar ao banco " + erro);
		}
			
		
	}
	
	
	public void criarCliente(String nome, String cpf, String email, String nascimento) {
		
		try {
			
			String query = "insert into cliente(nome, cpf, email, nascimento) values('"+ nome +"', '"+ cpf +"', '"+ email +"', '"+ nascimento +"');";
			
			System.out.println(query);
			
			this.state.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Dados pessoais cadastrados com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel coletar seus dados pessoais: " + erro);
		}
	}
	
	public void criarConta(String numero, String tipo, float saldo, String dono) {
		
		saldo = 0;
		try {
			
			
			String query = "insert into conta(numero, tipo, saldo, dono) values ('"+ numero + "', '"+ tipo +"', '"+ saldo +"', '"+ dono +"');";
			
			System.out.println(query);
			
			this.state.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Conta criada com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Conta criada com sucesso " + erro);
		}
	}
	
	
	public void depositar(String numero, float valor){
		
		try {
			
			String query = "update banco.conta set saldo = (saldo + '"+ valor +"') where numero = '"+ numero +"';";
			
			this.state.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Depósito no valor de " + valor + " realizado com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel realizar o depósito: " + erro);
		}
	}
	
	public void transferir(String conta1, float valor, String conta2) {
		
		try {
			
			
				
				String query = "update conta set saldo = (saldo - '"+ valor +"') where numero = '"+ conta1 +"';";
				
				String query2 = "update conta set saldo = (saldo + '"+ valor +"') where numero = '"+ conta2 +"';";
				
				
				
				this.state.executeUpdate(query);
				
				this.state.executeUpdate(query2);
				
				JOptionPane.showMessageDialog(null, "Transferencia realizada com sucesso para " + conta2);
				
			
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel realizar a transferencia " + erro);
		}
		
	}
	
	
	public void sacar(String numero, float valor) {
		
		try {
			
			String query = "update conta set saldo = (saldo - '"+ valor +"') where saldo >= '"+ valor+"' and numero = '"+ numero +"';";
			
			state.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Saque no valor de " + valor + " realizado: caso o saldo não seja suficiente você não"
					+ "receber o valor");
			
			
			
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel realizar o saque "+ erro);
			
		}
		
		
	}
	
	
	public void investir(String numero, float valor, float investimento) {
		
		
		try {
			
			String query = "update conta set saldo = (saldo - '"+ valor +"') where numero = '"+ numero +"';";
			
			String query2 = "update conta set saldo = (saldo + '"+ investimento +"') where numero = '"+ numero +"';";
			
			JOptionPane.showMessageDialog(null, "Valor investido: " + valor);
			
			JOptionPane.showMessageDialog(null, "Valor arrecado: " + investimento);
			
			if(investimento >= valor) {
				
				JOptionPane.showMessageDialog(null, "ROI: Positivo");
				
			}else {
				
				JOptionPane.showMessageDialog(null, "ROI: Negativo");
			}
			
			this.state.executeUpdate(query);
			
			this.state.executeUpdate(query2);
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel realizar o investimento: " + erro);
			
		}
		
	}
	
	
	public void saldo(String numero) {
		
		try {
			
			String query = "select saldo from conta where numero = '"+ numero +"';";
			
			this.resultado = this.state.executeQuery(query);
			
			while(this.resultado.next()) {
				
				JOptionPane.showMessageDialog(null, "Saldo atual: " + this.resultado.getFloat("saldo"));
			}
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel mostrar o saldo: " + erro);
		}
	}
	
	public void FiltrarTipoConta(String tipo) {
		
		try {
			
			String query = "select * from conta where tipo = '"+ tipo +"'";
			
			this.resultado = this.state.executeQuery(query);
			
			while(resultado.next()) {
				
				JOptionPane.showMessageDialog(null, "Numero: " + this.resultado.getString("numero") + " | tipo: " + this.resultado.getString("tipo") + " | Saldo: " + this.resultado.getFloat("saldo") + " | dono: " + this.resultado.getString("dono") );
			}
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel filtrar os tipos de contas: " + erro);
		}
		
	}
	
	public void atualizarCliente(String cpf, String nome, String email, String nascimento) {
		
		try {
			
			String query = "update cliente set nome = '"+ nome +"' where cpf = '"+ cpf +"';";
			
			String query2 = "update cliente set email = '"+ email +"' where cpf = '"+ cpf +"';";
			
			String query3 = "update cliente set nascimento = '"+ nascimento +"' where cpf = '"+ cpf +"';";
			
			this.state.executeUpdate(query);
			
			this.state.executeUpdate(query2);
			
			this.state.executeUpdate(query3);
			
			JOptionPane.showMessageDialog(null, "Dados atualizados com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel atualizar os dados pessoais: " + erro);
		}
		
	}
	
	
	public void atualizarConta(String numero, String novonumero, String tipo) {
		
		try {
			
			String query = "update conta set numero = '"+ novonumero +"' where numero = '"+ numero +"';";
			
			String query2 = "update conta set tipo = '"+ tipo +"' where numero = '"+ novonumero +"';";
					
			this.state.executeUpdate(query);
			
			this.state.executeUpdate(query2);
			
			JOptionPane.showMessageDialog(null, "Dados bancários atualizados com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel atualizar os dados bancários: " + erro);
			
		}
	}
	
	
	public void apagarConta(String numero, String cpf) {
		
		
		try {
			
			String query = "delete from conta where numero = '"+ numero +"'; ";
			
			String query2 = "delete from cliente where cpf = '"+ cpf +"';";
			
			this.state.executeUpdate(query);
			
			this.state.executeUpdate(query2);
			
			JOptionPane.showMessageDialog(null, "Conta Excluida com sucesso");
			
		}catch(SQLException | NullPointerException erro) {
			
			JOptionPane.showMessageDialog(null, "Não foi possivel excluir a sua conta: " + erro);
		}
	}
	
	
	
	
	public void desconectar() {
		
		try {
			
			conexao.close();
			
		}catch(SQLException erro) {
			
			JOptionPane.showMessageDialog(null, "Erro ao desconectar: " + erro);
		}
	}
}

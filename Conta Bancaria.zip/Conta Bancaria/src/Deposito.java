import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Deposito {

	JFrame frame;
	private JTextField txtconta;
	private JTextField txtvalor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Deposito window = new Deposito();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Deposito() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 921, 528);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Depósito");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(372, 39, 171, 44);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblconta = new JLabel("Informe a sua conta:");
		lblconta.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblconta.setBounds(186, 135, 202, 25);
		frame.getContentPane().add(lblconta);
		
		txtconta = new JTextField();
		txtconta.setBounds(385, 142, 96, 19);
		frame.getContentPane().add(txtconta);
		txtconta.setColumns(10);
		
		JLabel lblvalor = new JLabel("informe o valor que será depositado: ");
		lblvalor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblvalor.setBounds(48, 174, 355, 25);
		frame.getContentPane().add(lblvalor);
		
		txtvalor = new JTextField();
		txtvalor.setColumns(10);
		txtvalor.setBounds(385, 181, 96, 19);
		frame.getContentPane().add(txtvalor);
		
		JButton btndepositar = new JButton("Depositar");
		btndepositar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtconta.getText().length() > 4 || txtconta.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");					
				}
				
				float valor = Float.parseFloat(txtvalor.getText());
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				banco.depositar(txtconta.getText(), valor);
				banco.desconectar();
				
			}
		});
		btndepositar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btndepositar.setBounds(343, 266, 138, 44);
		frame.getContentPane().add(btndepositar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtconta.setText("");
				txtvalor.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(149, 266, 138, 44);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(532, 266, 183, 44);
		frame.getContentPane().add(btnvoltar);
	}

}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Saque {

	JFrame frame;
	private final JLabel lblsaque = new JLabel("Saque");
	private JTextField txtnumero;
	private JTextField txtvalor;
	private JButton btnlimpar;
	private JButton btnvoltar;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Saque window = new Saque();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Saque() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 743, 367);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		lblsaque.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblsaque.setBounds(274, 30, 126, 36);
		frame.getContentPane().add(lblsaque);
		
		JLabel lblnumero = new JLabel("Informe a sua conta:");
		lblnumero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnumero.setBounds(95, 87, 194, 43);
		frame.getContentPane().add(lblnumero);
		
		txtnumero = new JTextField();
		txtnumero.setBounds(283, 102, 96, 19);
		frame.getContentPane().add(txtnumero);
		txtnumero.setColumns(10);
		
		JLabel lblvalor = new JLabel("informe o valor a ser sacado:");
		lblvalor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblvalor.setBounds(33, 126, 241, 54);
		frame.getContentPane().add(lblvalor);
		
		txtvalor = new JTextField();
		txtvalor.setColumns(10);
		txtvalor.setBounds(283, 147, 96, 19);
		frame.getContentPane().add(txtvalor);
		
		JButton btnscar = new JButton("Sacar");
		btnscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				float valor = Float.parseFloat(txtvalor.getText());
				
				if(txtnumero.getText().length() < 4 || txtnumero.getText().length() > 4) {
					
					JOptionPane.showMessageDialog(null, "O numero da conta deve conter apenas 4 digitos");
				}
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				banco.sacar(txtnumero.getText(), valor);
				banco.desconectar();
			}
		});
		btnscar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnscar.setBounds(294, 222, 85, 43);
		frame.getContentPane().add(btnscar);
		
		btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnumero.setText("");
				txtvalor.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(176, 224, 98, 41);
		frame.getContentPane().add(btnlimpar);
		
		btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(407, 222, 183, 43);
		frame.getContentPane().add(btnvoltar);
	}
}

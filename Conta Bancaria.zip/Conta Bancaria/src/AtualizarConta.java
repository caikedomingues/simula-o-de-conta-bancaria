import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AtualizarConta {

	JFrame frame;
	private JTextField txtcontaatual;
	private JTextField txtnovonumero;
	private JTextField txttipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizarConta window = new AtualizarConta();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AtualizarConta() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 917, 480);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o numero da conta que terá os dados atualizados");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(186, 28, 575, 35);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblcontaatual = new JLabel("Numero atual da conta: ");
		lblcontaatual.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcontaatual.setBounds(175, 114, 214, 40);
		frame.getContentPane().add(lblcontaatual);
		
		txtcontaatual = new JTextField();
		txtcontaatual.setBounds(369, 128, 96, 19);
		frame.getContentPane().add(txtcontaatual);
		txtcontaatual.setColumns(10);
		
		JLabel lblnovonumero = new JLabel("Novo numero da conta: ");
		lblnovonumero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnovonumero.setBounds(175, 164, 214, 40);
		frame.getContentPane().add(lblnovonumero);
		
		txtnovonumero = new JTextField();
		txtnovonumero.setColumns(10);
		txtnovonumero.setBounds(369, 178, 96, 19);
		frame.getContentPane().add(txtnovonumero);
		
		JLabel lbltipo = new JLabel("novo tipo da conta:");
		lbltipo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lbltipo.setBounds(175, 214, 214, 40);
		frame.getContentPane().add(lbltipo);
		
		txttipo = new JTextField();
		txttipo.setColumns(10);
		txttipo.setBounds(369, 228, 96, 19);
		frame.getContentPane().add(txttipo);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtcontaatual.setText("");
				txtnovonumero.setText("");
				txttipo.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(164, 295, 135, 35);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(569, 295, 175, 35);
		frame.getContentPane().add(btnvoltar);
		
		JButton btnatualizar = new JButton("Atualizar");
		btnatualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtcontaatual.getText().length() > 4 || txtcontaatual.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
					
				}else if(txtnovonumero.getText().length() > 4 || txtnovonumero.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
					
				}else {
					
					Conexao banco = new Conexao();
					
					banco.conectar();
					banco.atualizarConta(txtcontaatual.getText(), txtnovonumero.getText(), txttipo.getText());
					banco.desconectar();
				}
			}
		});
		btnatualizar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnatualizar.setBounds(347, 295, 135, 35);
		frame.getContentPane().add(btnatualizar);
	}
}

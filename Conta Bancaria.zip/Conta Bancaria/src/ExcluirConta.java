import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExcluirConta {

	JFrame frame;
	private JTextField txtnumero;
	private JTextField txtcpf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExcluirConta window = new ExcluirConta();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ExcluirConta() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 792, 476);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Excluir Conta");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(263, 44, 175, 52);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblnumero = new JLabel("Numero da conta:");
		lblnumero.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblnumero.setBounds(146, 106, 183, 35);
		frame.getContentPane().add(lblnumero);
		
		txtnumero = new JTextField();
		txtnumero.setBounds(315, 118, 96, 19);
		frame.getContentPane().add(txtnumero);
		txtnumero.setColumns(10);
		
		JLabel lblcpf = new JLabel("Seu cpf:");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblcpf.setBounds(235, 151, 81, 35);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setColumns(10);
		txtcpf.setBounds(315, 163, 146, 19);
		frame.getContentPane().add(txtcpf);
		
		JButton btnexcluir = new JButton("Excluir conta");
		btnexcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtnumero.getText().length() > 4 || txtnumero.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
					
				}else if(txtcpf.getText().length() > 11 || txtcpf.getText().length() < 11) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 11 digitos");
					
				}else {
					
					Conexao banco = new Conexao();
					
					banco.conectar();
					banco.apagarConta(txtnumero.getText(), txtcpf.getText());
					banco.desconectar();
				}
				
			}
		});
		btnexcluir.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnexcluir.setBounds(296, 221, 146, 35);
		frame.getContentPane().add(btnexcluir);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnumero.setText("");
				txtcpf.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(134, 221, 135, 35);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(474, 221, 183, 35);
		frame.getContentPane().add(btnvoltar);
	}
}

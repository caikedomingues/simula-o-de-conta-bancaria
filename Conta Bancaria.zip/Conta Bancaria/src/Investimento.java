import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.util.Random;

public class Investimento {

	JFrame frame;
	private JTextField txtnumero;
	private JTextField txtvalor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Investimento window = new Investimento();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Investimento() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 651, 418);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Investimentos");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(251, 46, 137, 34);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblnumero = new JLabel("Numero da conta:");
		lblnumero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnumero.setBounds(85, 107, 179, 34);
		frame.getContentPane().add(lblnumero);
		
		txtnumero = new JTextField();
		txtnumero.setBounds(240, 118, 96, 19);
		frame.getContentPane().add(txtnumero);
		txtnumero.setColumns(10);
		
		JLabel lblvalor = new JLabel("Valor do investimento: ");
		lblvalor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblvalor.setBounds(53, 152, 211, 34);
		frame.getContentPane().add(lblvalor);
		
		txtvalor = new JTextField();
		txtvalor.setColumns(10);
		txtvalor.setBounds(240, 163, 96, 19);
		frame.getContentPane().add(txtvalor);
		
		JButton btnNewButton = new JButton("Investir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(txtnumero.getText().length() > 4 || txtnumero.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
					
				}else {
					
					Random inve = new Random();
					
					float investimento = inve.nextFloat(0,1001);
					
					float valor = Float.parseFloat(txtvalor.getText());
					
					Conexao banco = new Conexao();
					
					banco.conectar();
					
					banco.investir(txtnumero.getText(), valor, investimento);
					
					banco.desconectar();
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(251, 228, 110, 34);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnumero.setText("");
				txtvalor.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(104, 228, 110, 34);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Voltar");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(395, 228, 110, 34);
		frame.getContentPane().add(btnvoltar);
	}

}

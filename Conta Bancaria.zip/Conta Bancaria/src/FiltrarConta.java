import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FiltrarConta {

	JFrame frame;
	private JTextField txttipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FiltrarConta window = new FiltrarConta();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FiltrarConta() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 735, 476);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o tipo de conta que você quer verificar");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(149, 58, 477, 32);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblNewLabel = new JLabel("Informe o tipo de conta: cc ou cp:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(150, 125, 296, 22);
		frame.getContentPane().add(lblNewLabel);
		
		txttipo = new JTextField();
		txttipo.setBounds(443, 130, 96, 19);
		frame.getContentPane().add(txttipo);
		txttipo.setColumns(10);
		
		JButton btnfiltrar = new JButton("Filtrar");
		btnfiltrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				banco.FiltrarTipoConta(txttipo.getText());
				banco.desconectar();
			}
		});
		btnfiltrar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnfiltrar.setBounds(297, 192, 85, 32);
		frame.getContentPane().add(btnfiltrar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txttipo.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(149, 192, 119, 32);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(414, 192, 170, 32);
		frame.getContentPane().add(btnvoltar);
	}

}

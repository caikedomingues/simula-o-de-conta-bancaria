import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPrincipal {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal window = new TelaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 770, 904);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		JLabel lbltitulo = new JLabel("Menu Principal de Contas Bancárias");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(180, 41, 342, 25);
		frame.getContentPane().add(lbltitulo);
		
		JButton btnCriarConta = new JButton("CriarConta");
		btnCriarConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CriarConta window = new CriarConta();
				
				window.frame.setVisible(true);
			}
		});
		btnCriarConta.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCriarConta.setBounds(258, 133, 174, 46);
		frame.getContentPane().add(btnCriarConta);
		
		JButton btndepositar = new JButton("Depositar");
		btndepositar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Deposito window = new Deposito();
				
				window.frame.setVisible(true);
			}
		});
		btndepositar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btndepositar.setBounds(258, 218, 174, 46);
		frame.getContentPane().add(btndepositar);
		
		JButton btntransferir = new JButton("Transferencia");
		btntransferir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Transferir window = new Transferir();
				
				window.frame.setVisible(true);
			}
		});
		btntransferir.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btntransferir.setBounds(258, 301, 174, 46);
		frame.getContentPane().add(btntransferir);
		
		JButton btnsacar = new JButton("Saque");
		btnsacar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Saque window = new Saque();
				
				window.frame.setVisible(true);
			}
		});
		btnsacar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnsacar.setBounds(258, 387, 174, 46);
		frame.getContentPane().add(btnsacar);
		
		JButton btninvestir = new JButton("Investir");
		btninvestir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Investimento window = new Investimento();
				
				window.frame.setVisible(true);
			}
		});
		btninvestir.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btninvestir.setBounds(258, 462, 174, 46);
		frame.getContentPane().add(btninvestir);
		
		JButton btnslado = new JButton("Saldo");
		btnslado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Saldo window = new Saldo();
				
				window.frame.setVisible(true);
			}
		});
		btnslado.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnslado.setBounds(258, 540, 174, 46);
		frame.getContentPane().add(btnslado);
		
		JButton btnfiltrar = new JButton("Filtrar tipo de conta");
		btnfiltrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				FiltrarConta window = new FiltrarConta();
				
				window.frame.setVisible(true);
			}
		});
		btnfiltrar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnfiltrar.setBounds(246, 619, 217, 46);
		frame.getContentPane().add(btnfiltrar);
		
		JButton atualizar = new JButton("Atualizar dados pessoais");
		atualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AtualizarCliente window = new AtualizarCliente();
				
				window.frame.setVisible(true);
			}
		});
		atualizar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		atualizar.setBounds(227, 709, 268, 46);
		frame.getContentPane().add(atualizar);
		
		JButton btnatualizarbancario = new JButton("Atualizar dados bancários");
		btnatualizarbancario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AtualizarConta window = new AtualizarConta();
				
				window.frame.setVisible(true);
			}
		});
		btnatualizarbancario.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnatualizarbancario.setBounds(460, 133, 268, 46);
		frame.getContentPane().add(btnatualizarbancario);
		
		JButton btnatualizarbancario_1 = new JButton("Atualizar dados bancários");
		btnatualizarbancario_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnatualizarbancario_1.setBounds(460, 218, 268, 46);
		frame.getContentPane().add(btnatualizarbancario_1);
		
		JButton btnapagar = new JButton("Apagar conta bancária");
		btnapagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ExcluirConta window = new ExcluirConta();
				
				window.frame.setVisible(true);
			}
		});
		btnapagar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnapagar.setBounds(460, 301, 268, 46);
		frame.getContentPane().add(btnapagar);
		
		JButton btnsair = new JButton("Sair");
		btnsair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnsair.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnsair.setBounds(493, 387, 174, 46);
		frame.getContentPane().add(btnsair);
	}
}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CriarConta {

	JFrame frame;
	private JTextField txtnome;
	private JTextField txtcpf;
	private JTextField txtemail;
	private JTextField txtnascimento;
	private JTextField txtnumero;
	private JTextField txtconta;
	private JTextField txtdono;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CriarConta window = new CriarConta();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CriarConta() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1349, 766);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel titulodados = new JLabel("Informe os seus dados pessoais");
		titulodados.setFont(new Font("Tahoma", Font.PLAIN, 20));
		titulodados.setBounds(369, 65, 322, 25);
		frame.getContentPane().add(titulodados);
		
		JLabel lblnome = new JLabel("Nome:");
		lblnome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnome.setBounds(235, 135, 80, 25);
		frame.getContentPane().add(lblnome);
		
		txtnome = new JTextField();
		txtnome.setBounds(308, 141, 206, 19);
		frame.getContentPane().add(txtnome);
		txtnome.setColumns(10);
		
		JLabel lblcpf = new JLabel("Cpf:");
		lblcpf.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblcpf.setBounds(235, 182, 80, 25);
		frame.getContentPane().add(lblcpf);
		
		txtcpf = new JTextField();
		txtcpf.setColumns(10);
		txtcpf.setBounds(308, 188, 206, 19);
		frame.getContentPane().add(txtcpf);
		
		JLabel lblemail = new JLabel("Email:");
		lblemail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblemail.setBounds(235, 231, 80, 25);
		frame.getContentPane().add(lblemail);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(308, 237, 206, 19);
		frame.getContentPane().add(txtemail);
		
		JLabel lblnascimento = new JLabel("Ano de Nascimento:");
		lblnascimento.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnascimento.setBounds(131, 279, 184, 25);
		frame.getContentPane().add(lblnascimento);
		
		txtnascimento = new JTextField();
		txtnascimento.setColumns(10);
		txtnascimento.setBounds(308, 285, 206, 19);
		frame.getContentPane().add(txtnascimento);
		
		JLabel tituloconta = new JLabel("crie as informações da sua conta");
		tituloconta.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tituloconta.setBounds(351, 348, 340, 34);
		frame.getContentPane().add(tituloconta);
		
		JLabel lblnumero = new JLabel("Numero da conta (apenas 4 digitos):");
		lblnumero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnumero.setBounds(98, 407, 322, 34);
		frame.getContentPane().add(lblnumero);
		
		txtnumero = new JTextField();
		txtnumero.setBounds(433, 418, 158, 19);
		frame.getContentPane().add(txtnumero);
		txtnumero.setColumns(10);
		
		JLabel lbltipo = new JLabel("Tipo: cc (conta corrente) / cp (conta poupança):");
		lbltipo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lbltipo.setBounds(10, 451, 410, 34);
		frame.getContentPane().add(lbltipo);
		
		txtconta = new JTextField();
		txtconta.setColumns(10);
		txtconta.setBounds(433, 462, 158, 19);
		frame.getContentPane().add(txtconta);
		
		JLabel lbldono = new JLabel("informe novamente o seu cpf:");
		lbldono.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lbldono.setBounds(158, 495, 410, 34);
		frame.getContentPane().add(lbldono);
		
		txtdono = new JTextField();
		txtdono.setColumns(10);
		txtdono.setBounds(433, 506, 158, 19);
		frame.getContentPane().add(txtdono);
		
		JButton btnCriarConta = new JButton("Criar Conta");
		btnCriarConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Conexao banco = new Conexao();
				
				if(txtcpf.getText().length() > 11 || txtcpf.getText().length() < 11) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 11 digitos");
				}
				
				if(txtnumero.getText().length() > 4 || txtnumero.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "O numero deve conter apenas 4 digitos");
				}
				
				if(txtdono.getText().length() > 11 || txtdono.getText().length() < 11) {
					
					JOptionPane.showMessageDialog(null, "O cpf deve conter apenas 11 digitos");
				}
				
				
				
				
				banco.conectar();
				banco.criarCliente(txtnome.getText(), txtcpf.getText(), txtemail.getText(), txtnascimento.getText());
				banco.criarConta(txtnumero.getText(), txtconta.getText(), 0, txtdono.getText());
				banco.desconectar();
				
			}
		});
		btnCriarConta.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCriarConta.setBounds(466, 599, 125, 46);
		frame.getContentPane().add(btnCriarConta);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnome.setText("");
				txtcpf.setText("");
				txtemail.setText("");
				txtnascimento.setText("");
				txtnumero.setText("");
				txtconta.setText("");
				txtdono.setText("");
				
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(308, 599, 125, 46);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnVoltar = new JButton("Menu Principal");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnVoltar.setBounds(637, 599, 169, 46);
		frame.getContentPane().add(btnVoltar);
	}
}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AtualizarCliente {

	JFrame frame;
	private JTextField txtcpf;
	private JTextField txtnome;
	private JTextField txtemail;
	private JTextField txtnascimento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtualizarCliente window = new AtualizarCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AtualizarCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 844, 531);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Informe o cpf do cliente que terá os dados atualizados");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(143, 57, 513, 45);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblNewLabel = new JLabel("CPF:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(166, 131, 45, 13);
		frame.getContentPane().add(lblNewLabel);
		
		txtcpf = new JTextField();
		txtcpf.setBounds(221, 131, 145, 19);
		frame.getContentPane().add(txtcpf);
		txtcpf.setColumns(10);
		
		JLabel lblnome = new JLabel("Nome:");
		lblnome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnome.setBounds(153, 169, 68, 22);
		frame.getContentPane().add(lblnome);
		
		txtnome = new JTextField();
		txtnome.setColumns(10);
		txtnome.setBounds(221, 172, 145, 19);
		frame.getContentPane().add(txtnome);
		
		JLabel lblemail = new JLabel("Email:");
		lblemail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblemail.setBounds(153, 214, 68, 22);
		frame.getContentPane().add(lblemail);
		
		txtemail = new JTextField();
		txtemail.setColumns(10);
		txtemail.setBounds(221, 219, 145, 19);
		frame.getContentPane().add(txtemail);
		
		JLabel lblnascimento = new JLabel("Nascimento:");
		lblnascimento.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnascimento.setBounds(106, 255, 100, 22);
		frame.getContentPane().add(lblnascimento);
		
		txtnascimento = new JTextField();
		txtnascimento.setColumns(10);
		txtnascimento.setBounds(221, 260, 145, 19);
		frame.getContentPane().add(txtnascimento);
		
		JButton btnatualizar = new JButton("Atualizar");
		btnatualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				
				banco.atualizarCliente(txtcpf.getText(), txtnome.getText(), txtemail.getText(), txtnascimento.getText());
				
				banco.desconectar();
			}
		});
		btnatualizar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnatualizar.setBounds(281, 320, 118, 45);
		frame.getContentPane().add(btnatualizar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtcpf.setText("");
				txtnome.setText("");
				txtemail.setText("");
				txtnascimento.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(130, 320, 118, 38);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(438, 320, 174, 45);
		frame.getContentPane().add(btnvoltar);
	}

}

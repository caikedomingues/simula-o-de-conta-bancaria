import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Saldo {

	JFrame frame;
	private JTextField txtnumero;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Saldo window = new Saldo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Saldo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 734, 343);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbltitulo = new JLabel("Verifique o seu saldo");
		lbltitulo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lbltitulo.setBounds(230, 40, 197, 35);
		frame.getContentPane().add(lbltitulo);
		
		JLabel lblnumero = new JLabel("Numero da conta:");
		lblnumero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblnumero.setBounds(135, 115, 159, 27);
		frame.getContentPane().add(lblnumero);
		
		txtnumero = new JTextField();
		txtnumero.setBounds(284, 122, 96, 19);
		frame.getContentPane().add(txtnumero);
		txtnumero.setColumns(10);
		
		JButton btnsaldo = new JButton("Verificar saldo");
		btnsaldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				banco.saldo(txtnumero.getText());
				banco.desconectar();
			}
		});
		btnsaldo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnsaldo.setForeground(new Color(0, 0, 0));
		btnsaldo.setBounds(255, 191, 159, 35);
		frame.getContentPane().add(btnsaldo);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtnumero.setText("");
			}
		});
		btnlimpar.setForeground(Color.BLACK);
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(53, 191, 159, 35);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Menu Principal");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setForeground(Color.BLACK);
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(454, 191, 159, 35);
		frame.getContentPane().add(btnvoltar);
	}

}

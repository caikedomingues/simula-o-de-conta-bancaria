import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Transferir {

	JFrame frame;
	private JTextField txtconta1;
	private JTextField txtconta2;
	private JTextField txtvalor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Transferir window = new Transferir();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Transferir() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 916, 593);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Transferencias");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(277, 49, 227, 25);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblconta1 = new JLabel("Informe a sua conta: ");
		lblconta1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblconta1.setBounds(251, 115, 184, 39);
		frame.getContentPane().add(lblconta1);
		
		txtconta1 = new JTextField();
		txtconta1.setBounds(445, 128, 96, 19);
		frame.getContentPane().add(txtconta1);
		txtconta1.setColumns(10);
		
		JLabel lblconta2 = new JLabel("Informe a conta que ira receber o valor:");
		lblconta2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblconta2.setBounds(99, 164, 357, 39);
		frame.getContentPane().add(lblconta2);
		
		txtconta2 = new JTextField();
		txtconta2.setColumns(10);
		txtconta2.setBounds(445, 177, 96, 19);
		frame.getContentPane().add(txtconta2);
		
		JLabel lblvalor = new JLabel(" Informe o valor da transferencia:");
		lblvalor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblvalor.setBounds(147, 217, 357, 39);
		frame.getContentPane().add(lblvalor);
		
		txtvalor = new JTextField();
		txtvalor.setColumns(10);
		txtvalor.setBounds(445, 230, 96, 19);
		frame.getContentPane().add(txtvalor);
		
		JButton btnNewButton = new JButton("Transferir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				float valor = Float.parseFloat(txtvalor.getText());
				
				if(txtconta1.getText().length() > 4 || txtconta1.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
				}
				
				if(txtconta2.getText().length() > 4 || txtconta2.getText().length() < 4) {
					
					JOptionPane.showMessageDialog(null, "A conta deve conter apenas 4 digitos");
				}
				
				Conexao banco = new Conexao();
				
				banco.conectar();
				banco.transferir(txtconta1.getText(), valor, txtconta2.getText());
				banco.desconectar();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(330, 308, 147, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtconta1.setText("");
				txtconta2.setText("");
				txtvalor.setText("");
			}
		});
		btnlimpar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnlimpar.setBounds(147, 308, 147, 39);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnvoltar = new JButton("Voltar");
		btnvoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				TelaPrincipal window = new TelaPrincipal();
				
				window.frame.setVisible(true);
			}
		});
		btnvoltar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnvoltar.setBounds(523, 308, 147, 39);
		frame.getContentPane().add(btnvoltar);
	}

}
